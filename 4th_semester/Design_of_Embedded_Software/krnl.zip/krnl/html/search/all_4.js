var searchData=
[
  ['deq_11',['deQ',['../krnl_8c.html#a7ac8496c83319bfc569e4fdab8149940',1,'krnl.c']]],
  ['dmy_5fprio_12',['DMY_PRIO',['../krnl_8h.html#acf2f4a8f04e484305e7c862c0cb39d63',1,'krnl.h']]],
  ['dmy_5fstk_13',['dmy_stk',['../krnl_8h.html#a38effc60e299ca322c0065e67270a933',1,'krnl.h']]],
  ['dmy_5fstk_5fsz_14',['DMY_STK_SZ',['../krnl_8h.html#a1159800af031443d866b321adaae60d8',1,'krnl.h']]],
  ['dynmemory_15',['DYNMEMORY',['../krnl_8h.html#a874598d88f6cf5a05743c4544de5d3f0',1,'krnl.h']]]
];
