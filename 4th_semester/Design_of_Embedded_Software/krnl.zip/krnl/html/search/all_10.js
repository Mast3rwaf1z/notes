var searchData=
[
  ['readme_117',['README',['../md_README.html',1,'']]],
  ['r_118',['r',['../structk__msg__t.html#aac75863785b0f241b90e49b440f9cd4a',1,'k_msg_t']]],
  ['rdsem_119',['rdSem',['../structk__rwlock__t.html#a080277bf6ca592dde2e2418ce4456249',1,'k_rwlock_t']]],
  ['rdwrsem_120',['rdwrSem',['../structk__rwlock__t.html#ae4aaf9b7e9e668d89390f134d10b23e5',1,'k_rwlock_t']]],
  ['readerwriter_121',['READERWRITER',['../krnl_8h.html#aa5ef77acfcc0043bc185e0a2485beb21',1,'krnl.h']]],
  ['readme_2emd_122',['README.md',['../README_8md.html',1,'']]]
];
