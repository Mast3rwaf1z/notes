var searchData=
[
  ['paq_231',['pAQ',['../krnl_8c.html#a39d231356e06de7246adccc268aa1147',1,'pAQ():&#160;krnl.c'],['../krnl_8h.html#a39d231356e06de7246adccc268aa1147',1,'pAQ():&#160;krnl.h']]],
  ['pbuf_232',['pBuf',['../structk__msg__t.html#ac1285a0d8e7c3925b8f7671d92553ef7',1,'k_msg_t']]],
  ['pdmy_233',['pDmy',['../krnl_8h.html#ac0ba8f7ce796b6b1e572f969328a2ca5',1,'krnl.h']]],
  ['pe_234',['pE',['../krnl_8c.html#a40fbdb3ae83ed2142131282188c01d88',1,'krnl.c']]],
  ['pmain_5fel_235',['pmain_el',['../krnl_8c.html#a80e96fa9f2ed99168a71edefd1fc47ae',1,'pmain_el():&#160;krnl.c'],['../krnl_8h.html#a80e96fa9f2ed99168a71edefd1fc47ae',1,'pmain_el():&#160;krnl.h']]],
  ['pred_236',['pred',['../structk__t.html#a600d8611c0af5f63b647ab12d219e0fb',1,'k_t']]],
  ['prio_237',['prio',['../structk__t.html#aa1391b25432054cc36e27e1a6fee01ef',1,'k_t']]],
  ['prun_238',['pRun',['../krnl_8c.html#a35d8daf7bc4e2ffe82f95963bcfdf857',1,'pRun():&#160;krnl.c'],['../krnl_8h.html#a35d8daf7bc4e2ffe82f95963bcfdf857',1,'pRun():&#160;krnl.h']]],
  ['psleepsem_239',['pSleepSem',['../krnl_8c.html#a6e675bcea12aa787eabf1ca6a9271ce8',1,'pSleepSem():&#160;krnl.c'],['../krnl_8h.html#a6e675bcea12aa787eabf1ca6a9271ce8',1,'pSleepSem():&#160;krnl.h']]],
  ['pt_240',['pt',['../structk__t.html#a96966aa8e17b68cb4469241809e1b928',1,'k_t']]]
];
