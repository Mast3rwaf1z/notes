var searchData=
[
  ['qhd_5fprio_116',['QHD_PRIO',['../krnl_8h.html#a1b9c26bcbff44833fe9893a79279d0ba',1,'krnl.h']]]
];
