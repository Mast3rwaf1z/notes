var searchData=
[
  ['cbi_3',['cbi',['../krnl_8h.html#a555e11de39c12f2211225aacafe06e06',1,'cbi():&#160;krnl.h'],['../krnl_8h.html#a555e11de39c12f2211225aacafe06e06',1,'cbi():&#160;krnl.h']]],
  ['ceiling_5fprio_4',['ceiling_prio',['../structk__t.html#a72e4320f03e2ea3aab43874cdcc51880',1,'k_t']]],
  ['ceilingfail_5',['CEILINGFAIL',['../krnl_8h.html#a2b15d07e0bd496763f2055cf006d2806',1,'krnl.h']]],
  ['clip_6',['clip',['../structk__t.html#ad58455e7feb435218e12629a6b8321b9',1,'k_t']]],
  ['cnt_7',['cnt',['../structk__msg__t.html#afffaeebfdb8d84f296755babf6f296a6',1,'k_msg_t']]],
  ['cnt1_8',['cnt1',['../structk__t.html#a7ef04bafaf2e57965dfa0c8a1d14d124',1,'k_t']]],
  ['cnt2_9',['cnt2',['../structk__t.html#a7ae00f43d917f25200fffd1a8defe5ef',1,'k_t']]],
  ['cnt3_10',['cnt3',['../structk__t.html#aec4d7232788478d29abb708ca07f6796',1,'k_t']]]
];
