var searchData=
[
  ['sbi_590',['sbi',['../krnl_8h.html#a0c2d2311a38720412c3a666d6562aac3',1,'krnl.h']]],
  ['sem_5fmax_5fvalue_591',['SEM_MAX_VALUE',['../krnl_8h.html#ad19aa3c51588a22a9ee6cff41740880a',1,'krnl.h']]],
  ['ss_592',['SS',['../k03priorityequal_8ino.html#a88f7782e210e61586baf33b93240d905',1,'SS():&#160;k03priorityequal.ino'],['../k03priorityequalfixed_8ino.html#a88f7782e210e61586baf33b93240d905',1,'SS():&#160;k03priorityequalfixed.ino']]],
  ['stak_5fhash_593',['STAK_HASH',['../krnl_8h.html#ae0f7f3fba8495af1a0d053fc1806bc09',1,'krnl.h']]],
  ['stk_594',['STK',['../k01myfirsttask_8ino.html#abbfd9a2b36c64f065ab28c8330bc5010',1,'STK():&#160;k01myfirsttask.ino'],['../k03asleep_8ino.html#abbfd9a2b36c64f065ab28c8330bc5010',1,'STK():&#160;k03asleep.ino'],['../k04periodic_8ino.html#abbfd9a2b36c64f065ab28c8330bc5010',1,'STK():&#160;k04periodic.ino'],['../k04periodic-clip_8ino.html#abbfd9a2b36c64f065ab28c8330bc5010',1,'STK():&#160;k04periodic-clip.ino'],['../krnlsimpledebugled_8ino.html#abbfd9a2b36c64f065ab28c8330bc5010',1,'STK():&#160;krnlsimpledebugled.ino'],['../k06syncsem_8ino.html#abbfd9a2b36c64f065ab28c8330bc5010',1,'STK():&#160;k06syncsem.ino'],['../k07mutexsem-adv_8ino.html#abbfd9a2b36c64f065ab28c8330bc5010',1,'STK():&#160;k07mutexsem-adv.ino'],['../k09msgq_8ino.html#abbfd9a2b36c64f065ab28c8330bc5010',1,'STK():&#160;k09msgq.ino'],['../k08isrsem_8ino.html#abbfd9a2b36c64f065ab28c8330bc5010',1,'STK():&#160;k08isrsem.ino']]],
  ['stksz_595',['STKSZ',['../k02twotasks_8ino.html#ad2b48e844d035de119361b4650e06929',1,'k02twotasks.ino']]]
];
