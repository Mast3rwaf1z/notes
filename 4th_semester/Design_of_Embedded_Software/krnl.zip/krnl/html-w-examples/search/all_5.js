var searchData=
[
  ['el_5fsize_31',['el_size',['../structk__msg__t.html#a9e6cf0aaaa54e2c69938457b2a16e512',1,'k_msg_t']]],
  ['enq_32',['enQ',['../krnl_8c.html#ab750c904258e717b40c17f55400ca3b2',1,'krnl.c']]],
  ['er2_33',['er2',['../k06syncsem_8ino.html#a62daf9d9c6b80ed7269b9c9a93478568',1,'k06syncsem.ino']]],
  ['err_34',['err',['../k04periodic_8ino.html#a6ce68847c12434f60d1b2654a3dc3409',1,'err():&#160;k04periodic.ino'],['../k04periodic-clip_8ino.html#a6ce68847c12434f60d1b2654a3dc3409',1,'err():&#160;k04periodic-clip.ino']]]
];
