var searchData=
[
  ['databufformsgq_445',['dataBufForMsgQ',['../k09msgq_8ino.html#a75ad6122df699e2ab87a596c4c9acd16',1,'k09msgq.ino']]],
  ['dmy_5fstk_446',['dmy_stk',['../krnl_8h.html#a38effc60e299ca322c0065e67270a933',1,'krnl.h']]]
];
