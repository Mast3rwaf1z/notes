var searchData=
[
  ['x_568',['x',['../k04periodic-clip_8ino.html#a6150e0515f7202e2fb518f7206ed97dc',1,'k04periodic-clip.ino']]],
  ['xx_569',['xx',['../isr03_8ino.html#ae1a64de0c6ede60122c618c190d5d9f1',1,'isr03.ino']]]
];
