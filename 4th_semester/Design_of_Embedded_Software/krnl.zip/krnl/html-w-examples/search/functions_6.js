var searchData=
[
  ['getdataincritregion_356',['getDataInCritRegion',['../k07mutexsem_8ino.html#adb5c186df12ec23a7f20bc16d3b01b12',1,'getDataInCritRegion(void):&#160;k07mutexsem.ino'],['../k07mutexsem-adv_8ino.html#adb5c186df12ec23a7f20bc16d3b01b12',1,'getDataInCritRegion(void):&#160;k07mutexsem-adv.ino']]]
];
