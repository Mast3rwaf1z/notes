var searchData=
[
  ['i_41',['i',['../k02twotasks_8ino.html#a59b5f70d95f641564c5199c696b87cfd',1,'k02twotasks.ino']]],
  ['if_42',['if',['../k08isrsem_8ino.html#aaf3c4d305e0a24a74e3ae102c3cd982d',1,'if(!k_running) goto exitt:&#160;k08isrsem.ino'],['../k08isrsem_8ino.html#a30c739e6e2c2daa41b41ba872814f276',1,'if(debounceTime &gt;(k_millis_counter - lastISR)):&#160;k08isrsem.ino'],['../k08isrsem_8ino.html#a77e19db7b43e3362f28d6b030e7ada40',1,'if(-1==ki_signal(syncSem)) ISRoverflow++:&#160;k08isrsem.ino']]],
  ['instructions_43',['instructions',['../isr05_8ino.html#aa6f64bb143522968770815d9e4fdf0df',1,'isr05.ino']]],
  ['interruptpin_44',['interruptPin',['../isr01_8ino.html#a3490172b2914bca71ba26e4421b0a97c',1,'interruptPin():&#160;isr01.ino'],['../isr03_8ino.html#a3490172b2914bca71ba26e4421b0a97c',1,'interruptPin():&#160;isr03.ino'],['../isr04_8ino.html#a3490172b2914bca71ba26e4421b0a97c',1,'interruptPin():&#160;isr04.ino'],['../k000intr1_8ino.html#a3490172b2914bca71ba26e4421b0a97c',1,'interruptPin():&#160;k000intr1.ino'],['../k000intr2_8ino.html#a3490172b2914bca71ba26e4421b0a97c',1,'interruptPin():&#160;k000intr2.ino']]],
  ['interruptpin0_45',['interruptPin0',['../isr02_8ino.html#a9f73412f7cc71bbef07405f61bcc51af',1,'isr02.ino']]],
  ['interruptpin1_46',['interruptPin1',['../isr02_8ino.html#a734a101cafded9b44fac7dac639f3f92',1,'isr02.ino']]],
  ['isr_47',['ISR',['../isr03_8ino.html#afea150fcd685610cb9f7672fce361e53',1,'ISR(INT0_vect):&#160;isr03.ino'],['../k000intr2_8ino.html#afea150fcd685610cb9f7672fce361e53',1,'ISR(INT0_vect):&#160;k000intr2.ino'],['../krnl_8c.html#a790cb408825575b88d1107608b1ff389',1,'ISR(KRNLTMRVECTOR, ISR_NAKED):&#160;krnl.c']]],
  ['isr01_2eino_48',['isr01.ino',['../isr01_8ino.html',1,'']]],
  ['isr02_2eino_49',['isr02.ino',['../isr02_8ino.html',1,'']]],
  ['isr03_2eino_50',['isr03.ino',['../isr03_8ino.html',1,'']]],
  ['isr04_2eino_51',['isr04.ino',['../isr04_8ino.html',1,'']]],
  ['isr05_2eino_52',['isr05.ino',['../isr05_8ino.html',1,'']]],
  ['isroverflow_53',['ISRoverflow',['../k08isrsem_8ino.html#a6c6991d0a7b91cadf689ec839f76ded7',1,'k08isrsem.ino']]]
];
