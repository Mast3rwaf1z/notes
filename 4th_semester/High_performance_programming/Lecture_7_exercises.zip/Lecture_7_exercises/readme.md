# lecture 7 exercises
These scripts are using sys.argv variable such that the script is made to be run with by: `python sequential_random_set.py 10000 100` to create a CSV with 10.000 elements and put them into 100 sets, all the other programs work the same way. I have edited them with try/except statements to avoid this exception but i prefer that it's run as i've mentioned.

as i've mentioned in my mail, the only explaination i have for why the parallel time and jit time is slower than sequential time is because i'm executing simple instructions. 

in case it still is an issue, my code is uploaded to my git repository at `https://github.com/Mast3rwaf1z/notes/tree/main/4th_semester/High_performance_programming/Lecture_7_exercises`