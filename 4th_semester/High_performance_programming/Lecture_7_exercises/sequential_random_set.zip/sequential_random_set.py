from math import floor
from random import randint
from os import system
from time import perf_counter

def gen_csv(elements:int):
    system("rm numbers.csv")
    numbers = [randint(0, 100) for _ in range(elements)]
    with open("numbers.csv", "w") as file:
        file.write(str(numbers[0]))
        for i in range(1, len(numbers)):
            file.write("," + str(numbers[i]))

def gen_set(elements:list[int]):
    print(elements)

def function(elements:int, sets:int):
    set_size = floor(elements/sets)
    # generate csv
    _pre = perf_counter()
    gen_csv(elements)

    # read and save the generated csv in memory
    with open("numbers.csv", "r") as file:
        _in = file.read()
        l = [int(element) for element in _in.split(sep=",")]

    # generate set elements
    result = [[l.pop(randint(0, len(l)-1)) for i in range(set_size)] for i in range(sets)]
    _post = perf_counter()
    
    #print result
    for set in result:
        print(set)
    print(f'remainder set: {l}')
    print(_post - _pre)
    

if __name__ == "__main__":
    from sys import argv
    elements = int(argv[1]) #n elements
    sets = int(argv[2]) #k sets
    function(elements, sets)